// admin/tools/send-all-scheduled.php
<?php
require_once __DIR__ . '/../../send-scheduled-emails.php';
