// admin/tools/send-all-scheduled.php
<?php
require_once __DIR__ . '/../../scripts/send-scheduled-emails.php';
